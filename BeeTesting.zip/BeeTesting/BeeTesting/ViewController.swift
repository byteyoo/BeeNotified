//  ViewController.swift
//  BeeTesting
//
//  Created by BeeNotified on 2/10/18.
//  Copyright © 2018 BeeNotified. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    
    //Create array for storage
    var nameArray = [String]()
    
    
    //Object associated with the top label box
    @IBOutlet weak var topLabel: UILabel!
    
    //Object associated with the bottom label box
    @IBOutlet weak var bottomLabel: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        print("Program started")
        //readJson()
        //print("Program ended")
        
        
        
        print("We started the viewDidLoad function")
        
        //Function call will request json data and print to console
        jsonDataRequest()
        
        print("We are inbetween jsonDataRequest and jsonDataToApp calls")
        
        //Function call will request json data and print it to iPhone simulator
        jsonDataToApp()
        

        
        
        
    }//viewDidLoad
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }//didReceiveMemoryWarning
    
    
    
    
    
    
    func readJson() {
        
        //creating a NSURL
        let url = NSURL(string: "http://beenotified.com/test.json")
        
        //fetching the data from the url
        URLSession.shared.dataTask(with: (url as? URL)!, completionHandler: {(data, response, error) -> Void in
            
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                
                //printing the json in console
                print(jsonObj!.value(forKey: "name")!)
                
                print(jsonObj)
                
                //getting the avengers tag array from json and converting it to NSArray
                if let heroeArray = jsonObj!.value(forKey: "name") as? NSArray {
                    //looping through all the elements
                    for heroe in heroeArray{
                        
                        //converting the element to a dictionary
                        if let heroeDict = heroe as? NSDictionary {
                            
                            //getting the name from the dictionary
                            if let name = heroeDict.value(forKey: "name") {
                                
                                //adding the name to the array
                                self.nameArray.append((name as? String)!)
                            }
                            
                        }
                    }
                }
                else
                {
                print("FUCK AEVERYTHING MAGN")
                }
                
                OperationQueue.main.addOperation({
                    //calling another function after fetching the json
                    //it will show the names to label
                    
                    
                    //Attach values to a label in iOS
                    //Also print to console
                    for name in self.nameArray{
                        print(name)
                        
                        self.bottomLabel.text = self.bottomLabel.text! + name + "\n"
                    }
                    
                })
            }
        }).resume()
        
    }//readJson
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //Send a request for JSON data and print some on the console
    func jsonDataRequest(){
        
        //Use Alamofire to launch a request for our URL
        Alamofire.request("http://www.beenotified.com/test.json").responseData { (response) -> Void in
        //Alamofire.request("https://livealbany-my.sharepoint.com/personal/jmuckell_albany_edu/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fjmuckell_albany_edu%2FDocuments%2FShared%20with%20Everyone%2Ftest%2Ejson&parent=%2Fpersonal%2Fjmuckell_albany_edu%2FDocuments%2FShared%20with%20Everyone&slrid=e9a2499e-003f-5000-1223-e110c71ad838").responseString { (response) -> Void in
            
            // retrieve our JSON data in the "values" variable
            if let data = response.result.value {
                var names = [String]()
                //Create SwiftyJSON object with our data
                do{
                    let str = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
                    
                    print(str)
                    //print(error)
                    
                } catch {
                    print("Error Serializing JSON: \(error)")
                }
                
                
            }//if JSON
            else {
                print("Bro something broke")
                print(response)
            }
            
            
            
        }//Alamofire request
        
    }//jsonDataRequest
    
    
    
    
    //Request some JSON data and print it in our app
    //Textboxes are called topLabel and bottomLabel
    func jsonDataToApp(){
        
        //Use Alamofire to launch a request for our URL
        Alamofire.request("http://www.beenotified.com/test.json").responseData { (response) -> Void in
            
            // retrieve our JSON data in the "values" variable
            if let data = response.result.value {
                var names = [String]()
                //Create SwiftyJSON object with our data
                do{
                    let str = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
                    
                    //print(str)
                    self.topLabel.text = str as! String
                    //print(error)
                    
                } catch {
                    print("Error Serializing JSON: \(error)")
                }
                
                
            }//if JSON
            else {
                print("Bro something broke")
                print(response)
            }
        
        
    }//jsonDataToApp
    
    
    

}//ViewController

}
